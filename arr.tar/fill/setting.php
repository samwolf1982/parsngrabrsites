<?php  


$GLOBALS['u_host']="127.0.0.1"; // Хост
$GLOBALS['u_user']="root"; // Имя пользователя
$GLOBALS['u_pass']=""; // Пароль
$GLOBALS['u_dbname']="testwp1"; // Имя базы данных
$GLOBALS['total_room']=0; 
$GLOBALS['filter']=false;
$GLOBALS['maxcount']=5;



$GLOBALS['u_host']="mysql12.000webhost.com"; // Хост
$GLOBALS['u_user']="a1100551_root"; // Имя пользователя
$GLOBALS['u_pass']="Dublianu1982"; // Пароль
$GLOBALS['u_dbname']="a1100551_testwp1"; // Имя базы данных


?>