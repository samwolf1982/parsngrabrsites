<?php
echo "string";
  ?>