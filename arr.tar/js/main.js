function rentLive(argument) {

// SELECT `day` as `День` , `time` as `Время` FROM `rent_living` WHERE 1


//v='[{"band":"Weezer","song":"El Scorcho"}, {"band": "Chevelle", "song": "Family System"} ]';
/*var $records = v;
    myRecords = $.parseJSON($records);
$('#my-final-table').dynatable({
  dataset: {
    records: myRecords
  }
});*/


$.ajax({
  url: 'rentlive.php',
  success: function(data){
                console.log(data);
    $('#my-final-table').dynatable({
      dataset: {
        records: $.parseJSON(data)
      }
    });
  }
});

};

$( document ).ready(function() {
  // Handler for .ready() called.
var myVar = setInterval(function() {

$.ajax({
  url: 'indexworker.php',
  success: function(data){
      console.log('to db OK');
  }
});



}, 240000);
//var timer=setTimeout(function() { console.log("timer 896");}, 1000); // 1000 1 sec
   



});





