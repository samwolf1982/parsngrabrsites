<?php
function timerfun($interval=5)
{
	# code...

	
}


?>