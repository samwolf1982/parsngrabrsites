<?php 

echo "test";
 ?>