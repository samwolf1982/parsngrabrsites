<?php
// TODO move them into directory
include 'test_1.php';
include 'test_2.php';
include 'test_3.php';
include 'test_4.php';
include 'test_5.php';
include 'test_wrap.php';
include 'test_replace.php';
include 'test_multidoc.php';
?>