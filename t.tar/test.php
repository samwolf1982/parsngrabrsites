<? php

 html body div:eq(1) div div:eq(1) div:first div:first div:first div:eq(4) table tbody tr:eq(1) td:eq(2) div:eq(2) div:first div:eq(1) div:eq(1) div:first

 html body div:eq(1) div div:eq(1) div div div div:eq(4) table tbody tr:eq(1) td:eq(2) div:eq(1)

 :eq(@id="advert-list-container") table tbody tr:eq(1) td:eq(2) div:eq(1)


tr.detailed-advert:nth-child(1)   td:nth-child(2)   div:nth-child(1)
tr.detailed-advert:nth-child(1)   td:nth-child(2)   div:nth-child(2)   div:nth-child(1)   div:nth-child(1)   div:nth-child(1)   div:nth-child(1)

tr.detailed-advert:nth-child(1) > td:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1)


tr.detailed-advert:nth-child(1) > td:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2) > a:nth-child(5)

tr.detailed-advert:nth-child(1) > td:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2)

tr.detailed-advert:nth-child(4) > td:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2)
